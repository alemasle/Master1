#include <stdio.h>
#include <stdlib.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>


int main(int argc, char* argv[]){
	
	int num_pid;
	long attache;
	FILE *adrmemoir;
	char str[512];
	char str1[512];
	char str2[512];
	char str3[512];
	FILE *proc;
	char npid[16];
	char stringadrmem[16];
	long unsigned  int adrmem;


	if (argv[1]== NULL){
		printf("Il faut mettre un parametre \n");
	}
	printf("programme %s \n",argv[1]);
	snprintf(str,sizeof("pgrep > proc.txt ")+sizeof(argv[1])-1, "pgrep %s > proc.txt", argv[1]);
	

	//recupere le pid avec fopen sinon si juste system c'est le code de retour de system que l'on recupere
	proc= fopen("proc.txt","r");

	if (proc == NULL){
		perror("fopen erreur pour proc.txt\n");
	}
	

	if(fread(npid,sizeof(char),15, proc)==0){
		perror("fread erreur pid \n");	
	}
	
	num_pid= atoi(npid);
	if(num_pid <0){
		perror("Erreur pgrep pour le processus demander \n");
		return -1;
	}

	printf("le numero du proc est :%d \n",num_pid);

	//attache le processus
	attache=ptrace(PTRACE_ATTACH, num_pid,0,0);
	if(attache < 0){
		perror("Erreur processus non attaché\n");
		return -1;
	}
	
	//on attend que ca finisse avec waitpid
	wait(&num_pid);
	
	//penser à proc/pid/
	//pour acceder à la mémoire du processus avec open, read et lseek

	// PARTI DES ADRESSE MEMOIRE
	

	printf("on prends l'adresse memoire de la fonction: %s du programme %s  \n",argv[2],argv[1]);
	snprintf(str3,sizeof("nm | pgrep > adresseMemoire.txt ")+sizeof(argv[1])+sizeof(argv[2]),"nm %s | pgrep %s > adresseMemoire.txt", argv[1],argv[2]);


	adrmemoir= fopen("adresseMemoire.txt","r");


	if (adrmemoir ==NULL){
		perror("fopen erreur adrmemoir.txt\n");
	}

	if(fread(stringadrmem,20,sizeof(char), adrmemoir)==0){
		perror("fread erreur adrmemoire\n");	
	}
	sscanf(stringadrmem,"%lx %s %s", &adrmem,str1,str2);//adrmem contient l'adresse memoire
	printf("l'adresse est : %lx \n", adrmem);


	//on ferme
	if(fclose(proc)<0){
		perror("erreur sur la fermeture de proc");
	}
	if(fclose(adrmemoir)<0){
		perror("erreur sur la fermeture de adrmemoir");
	}
	return 0;
}







